
import React from 'react';
import { ChevronDownIcon } from './Icons';

const days = [
  { day: 'Mon', date: 11, active: false },
  { day: 'Tue', date: 12, active: true },
  { day: 'Wed', date: 13, active: false },
  { day: 'Thu', date: 14, active: false },
  { day: 'Fri', date: 15, active: false },
  { day: 'Sat', date: 16, active: false },
  { day: 'Sun', date: 17, active: false },
];

const MatchCard: React.FC<{team1: string, team2: string, score1: number, score2: number, logo1: string, logo2: string}> = ({team1, team2, score1, score2, logo1, logo2}) => (
    <div className="bg-slate-800/70 border border-blue-500/20 rounded-2xl p-4 space-y-4">
        <div className="flex justify-between items-center">
            <span className="text-xs bg-slate-700 px-2 py-1 rounded-md font-semibold">1/2 Finals</span>
            <div className="flex items-center gap-4">
                <div className="flex flex-col items-end gap-1">
                    <span className="font-bold text-sm">{team1}</span>
                    <img src={logo1} alt={team1} className="w-8 h-8 rounded-full border-2 border-slate-600"/>
                </div>
                <div className="text-center">
                    <span className="text-2xl font-black text-yellow-400">{score1}</span>
                    <span className="text-2xl font-black mx-1 text-gray-500">:</span>
                    <span className="text-2xl font-black">{score2}</span>
                </div>
                <div className="flex flex-col items-start gap-1">
                    <span className="font-bold text-sm">{team2}</span>
                    <img src={logo2} alt={team2} className="w-8 h-8 rounded-full border-2 border-slate-600"/>
                </div>
            </div>
        </div>
        <div className="flex justify-center gap-3">
            <button className="bg-orange-600/80 hover:bg-orange-500/80 text-white font-bold py-2 px-6 rounded-lg text-sm flex items-center gap-2">
                <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></span>
                Watch
            </button>
            <button className="bg-cyan-600/80 hover:bg-cyan-500/80 text-white font-bold py-2 px-6 rounded-lg text-sm flex items-center gap-2">
                <span className="w-2 h-2 bg-green-400 rounded-full"></span>
                Statistics
            </button>
        </div>
    </div>
);

const ScheduleScreen: React.FC = () => {
  return (
    <div className="space-y-4 pb-4">
      {/* Date and Calendar */}
      <section>
        <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-bold">12 May, 2023</h2>
        </div>
        <div className="flex justify-between items-center gap-2">
          {days.map(({ day, date, active }) => (
            <div key={date} className={`flex flex-col items-center justify-center w-12 h-16 rounded-lg transition-all duration-300 ${active ? 'bg-yellow-400 text-black shadow-lg shadow-yellow-400/20' : 'bg-slate-800/60'}`}>
              <span className="text-xs">{day}</span>
              <span className="font-bold text-lg">{date}</span>
            </div>
          ))}
        </div>
      </section>

      {/* Filter */}
      <section>
        <button className="w-full flex justify-between items-center bg-slate-800/60 p-3 rounded-lg border border-slate-700">
            <span className="font-semibold">Hockey</span>
            <ChevronDownIcon className="w-5 h-5"/>
        </button>
      </section>

      {/* Match List */}
      <section className="space-y-4">
          <MatchCard team1="Crazy Tiger" team2="Arizona's D..." score1={0} score2={2} logo1="https://picsum.photos/id/40/50" logo2="https://picsum.photos/id/48/50"/>
          <MatchCard team1="Boston Military" team2="Buffalo Jackals" score1={2} score2={3} logo1="https://picsum.photos/id/54/50" logo2="https://picsum.photos/id/60/50"/>
      </section>
    </div>
  );
};

export default ScheduleScreen;
