import React from 'react';
import { NavLink } from 'react-router-dom';
import { GroupIcon, LeagueIcon, HomeIcon, TransferIcon, StoreIcon } from './Icons';

const navItems = [
  { path: '/group', icon: GroupIcon, label: 'GROUP' },
  { path: '/league', icon: LeagueIcon, label: 'LEAGUE' },
  { path: '/', icon: HomeIcon, label: 'HOME' },
  { path: '/transfer', icon: TransferIcon, label: 'TRANSFER' },
  { path: '/store', icon: StoreIcon, label: 'STORE' },
];

const FooterNav: React.FC = () => {
  return (
    <footer className="bg-slate-900/60 backdrop-blur-md border-t border-cyan-500/20">
      <nav className="flex justify-around items-center h-20">
        {navItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            end={item.path === '/'}
            className={({ isActive }) =>
              `flex flex-col items-center gap-1 text-xs font-medium transition-all duration-300 ${
                isActive ? 'text-cyan-400 scale-110' : 'text-gray-500 hover:text-cyan-300'
              }`
            }
          >
            {({ isActive }) => {
              const Icon = item.icon;
              return (
                <>
                  <div className="relative">
                    <Icon className="w-7 h-7" />
                    {isActive && (
                      <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-8 h-1 bg-cyan-400 rounded-full blur-[3px]"></div>
                    )}
                  </div>
                  <span>{item.label}</span>
                </>
              );
            }}
          </NavLink>
        ))}
      </nav>
    </footer>
  );
};

export default FooterNav;
