
import React, { useState } from 'react';

const leagueTabs = ["CALENDAR", "TOURNAMENTS", "PLAYOFFS", "STATISTICS"];

const leagueData = [
    { pos: 1, logo: 'https://picsum.photos/id/10/40', name: 'Eagle', w: 21, l: 7, wlRatio: '52/39', points: 28 },
    { pos: 2, logo: 'https://picsum.photos/id/11/40', name: 'Alligator', w: 21, l: 13, wlRatio: '40/28', points: 26, isUser: true },
    { pos: 3, logo: 'https://picsum.photos/id/12/40', name: 'Falcon', w: 20, l: 15, wlRatio: '37/23', points: 30 },
    { pos: 4, logo: 'https://picsum.photos/id/13/40', name: 'Boston', w: 19, l: 10, wlRatio: '42/28', points: 26 },
    { pos: 5, logo: 'https://picsum.photos/id/14/40', name: 'Dragon', w: 20, l: 15, wlRatio: '37/23', points: 30 },
];

const LeagueScreen: React.FC = () => {
    const [activeTab, setActiveTab] = useState("STATISTICS");

    return (
        <div className="space-y-4 pb-4">
            <h1 className="text-xl font-bold text-center text-cyan-300">League level 15</h1>
            
            {/* Sub Navigation */}
            <nav className="flex justify-between items-center bg-slate-800/50 p-1 rounded-lg border border-slate-700">
                {leagueTabs.map(tab => (
                    <button 
                        key={tab}
                        onClick={() => setActiveTab(tab)}
                        className={`w-full text-center text-xs font-bold py-2 rounded-md transition-all duration-300 ${
                            activeTab === tab ? 'bg-cyan-500 text-slate-900 shadow-lg shadow-cyan-500/20' : 'text-gray-400'
                        }`}
                    >
                        {tab}
                    </button>
                ))}
            </nav>

            {/* Team Info Section */}
            <section className="bg-slate-800/70 border border-blue-500/20 rounded-2xl p-4">
                <div className="flex items-center gap-3">
                    <img src="https://picsum.photos/id/10/50" alt="Fast Eagle Wings" className="w-12 h-12 rounded-full" />
                    <div>
                        <h3 className="font-bold">Fast Eagle Wings</h3>
                        <p className="text-xs text-gray-400">The NHL Draft Lottery is a weighted lottery...</p>
                    </div>
                </div>
                <div className="grid grid-cols-3 gap-4 text-center mt-4">
                    <div>
                        <p className="text-sm text-green-400">VICTORIES</p>
                        <p className="text-3xl font-bold">21</p>
                    </div>
                     <div>
                        <p className="text-sm text-gray-400">GAMES</p>
                        <p className="text-3xl font-bold">24</p>
                    </div>
                    <div>
                        <p className="text-sm text-red-400">DEFEATS</p>
                        <p className="text-3xl font-bold">3</p>
                    </div>
                </div>
                <div className="mt-4">
                    <p className="text-center text-xs text-gray-400 mb-1">TEAM POSITION</p>
                    <div className="w-full bg-slate-700 rounded-full h-2.5 relative">
                        <div className="bg-gradient-to-r from-red-500 via-yellow-500 to-green-500 h-2.5 rounded-full"></div>
                        <div className="absolute top-1/2 -translate-y-1/2 bg-white rounded-full h-4 w-4 border-2 border-slate-900" style={{ left: 'calc(80% - 8px)' }}></div>
                    </div>
                </div>
            </section>

            {/* Standings Table */}
            <section className="space-y-1">
                 <div className="grid grid-cols-12 gap-2 text-xs text-gray-400 font-bold px-2 py-1">
                    <div className="col-span-1">#</div>
                    <div className="col-span-4">TEAM</div>
                    <div className="col-span-2 text-center">W/L</div>
                    <div className="col-span-3 text-center">STAT</div>
                    <div className="col-span-2 text-right">PTS</div>
                </div>
                {leagueData.map(team => (
                    <div key={team.pos} className={`grid grid-cols-12 gap-2 items-center text-sm p-2 rounded-lg ${team.isUser ? 'bg-green-500/20 border-l-4 border-green-400' : 'bg-slate-800/50'}`}>
                        <div className="col-span-1 font-bold">{team.pos}</div>
                        <div className="col-span-4 flex items-center gap-2">
                            <img src={team.logo} alt={team.name} className="w-6 h-6 rounded-full"/>
                            <span className="font-semibold">{team.name}</span>
                        </div>
                        <div className="col-span-2 text-center">{team.w} / {team.l}</div>
                        <div className="col-span-3 text-center text-gray-400 text-xs">{team.wlRatio}</div>
                        <div className="col-span-2 text-right font-bold text-yellow-300">{team.points}</div>
                    </div>
                ))}
            </section>
        </div>
    );
};

export default LeagueScreen;
