import React from 'react';
import { Link } from 'react-router-dom';
import { GoalsIcon, LeagueIcon, FriendsIcon, SharkLogo } from './Icons';

const QuickNavButton: React.FC<{ icon: React.ReactNode; label: string; to: string }> = ({ icon, label, to }) => (
  <Link to={to} className="flex flex-col items-center justify-center gap-2 bg-slate-800/50 hover:bg-slate-700/50 border border-cyan-500/20 rounded-xl p-3 w-full text-center transition-all duration-300">
    <div className="text-cyan-400">{icon}</div>
    <span className="text-sm font-semibold tracking-wider">{label}</span>
  </Link>
);

const TeamLogo: React.FC<{ src: string; alt: string }> = ({ src, alt }) => (
    <div className="w-12 h-12 bg-slate-700 rounded-full flex items-center justify-center">
        <img src={src} alt={alt} className="w-10 h-10 object-contain"/>
    </div>
);


const HomeScreen: React.FC = () => {
  return (
    <div className="space-y-6 pb-4">
      {/* Team Profile Section */}
      <section className="flex flex-col items-center text-center -mt-4">
        <div className="w-36 h-36 drop-shadow-[0_0_15px_rgba(0,200,255,0.7)]">
            <SharkLogo className="w-full h-full" />
        </div>
        <h2 className="text-lg font-bold tracking-wider mt-2">Player 18649890</h2>
        <p className="text-sm text-cyan-400">TEAM STATUS</p>
      </section>

      {/* Quick Navigation */}
      <section className="flex justify-center items-center gap-3">
        <QuickNavButton icon={<GoalsIcon className="w-6 h-6" />} label="GOALS" to="/goals" />
        <QuickNavButton icon={<LeagueIcon className="w-6 h-6" />} label="LEAGUE" to="/league" />
        <QuickNavButton icon={<FriendsIcon className="w-6 h-6" />} label="FRIENDS" to="/friends" />
      </section>

      {/* Past Match Card */}
      <div className="bg-gradient-to-b from-slate-800/80 to-slate-900/50 backdrop-blur-sm border border-blue-500/20 rounded-2xl p-4 space-y-3">
        <h3 className="font-bold text-blue-300 text-center text-sm tracking-widest">PAST MATCH</h3>
        <div className="flex items-center justify-around">
            <div className="flex flex-col items-center gap-2">
                <TeamLogo src="https://picsum.photos/id/23/50" alt="Fighter Team"/>
                <span className="text-xs font-semibold">Player</span>
                <span className="text-xs text-gray-400">18649809</span>
            </div>
            <div className="text-center">
                <span className="text-4xl font-black text-yellow-400">2</span>
                <span className="text-4xl font-black mx-2">:</span>
                <span className="text-4xl font-black">3</span>
            </div>
             <div className="flex flex-col items-center gap-2">
                <TeamLogo src="https://picsum.photos/id/24/50" alt="Opponent Team"/>
                <span className="text-xs font-semibold">Player</span>
                <span className="text-xs text-gray-400">18359787</span>
            </div>
        </div>
      </div>

      {/* Upcoming League Game Card */}
       <div className="bg-gradient-to-b from-slate-800/80 to-slate-900/50 backdrop-blur-sm border border-blue-500/20 rounded-2xl p-4 space-y-3">
        <h3 className="font-bold text-blue-300 text-center text-sm tracking-widest">UPCOMING LEAGUE GAME</h3>
        <div className="flex items-center justify-around">
            <div className="flex flex-col items-center gap-2">
                <TeamLogo src="https://picsum.photos/id/25/50" alt="Falcon Team"/>
                <span className="font-bold">FALCON</span>
                 <span className="text-xs text-gray-400">Player 18649809</span>
            </div>
            <span className="text-2xl font-bold text-gray-500">VS</span>
             <div className="flex flex-col items-center gap-2">
                <TeamLogo src="https://picsum.photos/id/28/50" alt="Alligator Team"/>
                <span className="font-bold">ALLIGATOR</span>
                <span className="text-xs text-gray-400">Player 18359787</span>
            </div>
        </div>
        <div className="pt-2">
            <div className="flex justify-between items-center text-xs text-gray-400 mb-1">
                <span>READINESS FOR THE MATCH</span>
                <span className="font-bold text-lime-300">46%</span>
            </div>
            <div className="w-full bg-slate-700 rounded-full h-2.5">
                <div className="bg-gradient-to-r from-cyan-400 to-lime-400 h-2.5 rounded-full" style={{width: '46%'}}></div>
            </div>
        </div>
      </div>
    </div>
  );
};

export default HomeScreen;