import React, { FormEvent } from 'react';
import { useNavigate, Link } from 'react-router-dom';

const RegisterScreen: React.FC = () => {
  const navigate = useNavigate();

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    // In a real app, you would handle registration API call here
    alert('Registration successful! Please log in.');
    navigate('/login');
  };

  return (
    <div className="w-[390px] h-[844px] bg-gradient-to-b from-[#0a101f] to-[#121a33] rounded-[40px] overflow-hidden shadow-2xl flex flex-col items-center justify-center p-8 border-4 border-gray-800 text-gray-200">
      <h1 className="text-3xl font-bold text-lime-300 mb-2">Create Account</h1>
      <p className="text-gray-400 mb-8">Join the league today.</p>

      <form onSubmit={handleSubmit} className="w-full space-y-6">
        <div>
          <label htmlFor="email" className="block text-sm font-medium text-gray-400 mb-2">Email</label>
          <input
            type="email"
            id="email"
            className="w-full bg-slate-800/50 border border-slate-700 rounded-lg px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-lime-500 transition-all"
            required
          />
        </div>
        <div>
          <label htmlFor="password"  className="block text-sm font-medium text-gray-400 mb-2">Password</label>
          <input
            type="password"
            id="password"
            className="w-full bg-slate-800/50 border border-slate-700 rounded-lg px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-lime-500 transition-all"
            required
          />
        </div>
         <div>
          <label htmlFor="confirm-password"  className="block text-sm font-medium text-gray-400 mb-2">Confirm Password</label>
          <input
            type="password"
            id="confirm-password"
            className="w-full bg-slate-800/50 border border-slate-700 rounded-lg px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-lime-500 transition-all"
            required
          />
        </div>
        <button type="submit" className="w-full bg-lime-500 hover:bg-lime-400 text-slate-900 font-bold py-3 rounded-lg shadow-lg shadow-lime-500/20 transition-all duration-300">
          Register
        </button>
      </form>

      <p className="mt-8 text-sm text-gray-400">
        Already have an account?{' '}
        <Link to="/login" className="font-semibold text-cyan-400 hover:text-cyan-300">
          Sign In
        </Link>
      </p>
    </div>
  );
};

export default RegisterScreen;
