import React from 'react';
import { useAuth } from '../auth/AuthContext';
import { CoinIcon, GemIcon, SettingsIcon, LogoutIcon } from './Icons';

const Header: React.FC = () => {
  const { logout } = useAuth();
  return (
    <header className="flex items-center justify-between p-4 bg-[#0a101f]/50 backdrop-blur-sm z-10">
      {/* Left Side */}
      <div className="flex items-center gap-3">
        <div className="relative">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-yellow-400 to-orange-500 flex items-center justify-center text-black font-bold text-lg shadow-md">
            28
          </div>
        </div>
        <button className="text-gray-400 hover:text-white transition-colors">
          <SettingsIcon className="w-6 h-6" />
        </button>
      </div>

      {/* Right Side */}
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2 bg-slate-800/50 px-3 py-1.5 rounded-full border border-slate-700">
          <CoinIcon className="w-5 h-5" />
          <span className="font-bold text-sm text-yellow-300">65</span>
        </div>
        <div className="flex items-center gap-2 bg-slate-800/50 px-3 py-1.5 rounded-full border border-slate-700">
          <GemIcon className="w-5 h-5" />
          <span className="font-bold text-sm text-green-300">149.1K</span>
        </div>
         <button onClick={logout} className="text-gray-400 hover:text-red-400 transition-colors" aria-label="Logout">
          <LogoutIcon className="w-6 h-6" />
        </button>
      </div>
    </header>
  );
};

export default Header;