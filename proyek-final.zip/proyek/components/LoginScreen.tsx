import React, { FormEvent } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';
import { SharkLogo } from './Icons';

const LoginScreen: React.FC = () => {
  const navigate = useNavigate();
  const { login } = useAuth();

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    login();
    navigate('/');
  };

  return (
    <div className="w-[390px] h-[844px] bg-gradient-to-b from-[#0a101f] to-[#121a33] rounded-[40px] overflow-hidden shadow-2xl flex flex-col items-center justify-center p-8 border-4 border-gray-800 text-gray-200">
      <div className="w-36 h-36 drop-shadow-[0_0_15px_rgba(0,200,255,0.7)] mb-4">
        <SharkLogo className="w-full h-full" />
      </div>
      <h1 className="text-3xl font-bold text-cyan-300 mb-2">Welcome Back</h1>
      <p className="text-gray-400 mb-8">Login to your command center.</p>

      <form onSubmit={handleSubmit} className="w-full space-y-6">
        <div>
          <label htmlFor="email" className="block text-sm font-medium text-gray-400 mb-2">Email</label>
          <input
            type="email"
            id="email"
            defaultValue="player@esports.com"
            className="w-full bg-slate-800/50 border border-slate-700 rounded-lg px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-cyan-500 transition-all"
            required
          />
        </div>
        <div>
          <label htmlFor="password"  className="block text-sm font-medium text-gray-400 mb-2">Password</label>
          <input
            type="password"
            id="password"
            defaultValue="password123"
            className="w-full bg-slate-800/50 border border-slate-700 rounded-lg px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-cyan-500 transition-all"
            required
          />
        </div>
        <button type="submit" className="w-full bg-cyan-500 hover:bg-cyan-400 text-slate-900 font-bold py-3 rounded-lg shadow-lg shadow-cyan-500/20 transition-all duration-300">
          Login
        </button>
      </form>

      <p className="mt-8 text-sm text-gray-400">
        Don't have an account?{' '}
        <Link to="/register" className="font-semibold text-lime-400 hover:text-lime-300">
          Sign Up
        </Link>
      </p>
    </div>
  );
};

export default LoginScreen;
