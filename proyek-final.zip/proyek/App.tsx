import React from 'react';
import { HashRouter, Routes, Route, Outlet, Navigate } from 'react-router-dom';
import Header from './components/Header';
import FooterNav from './components/FooterNav';
import HomeScreen from './components/HomeScreen';
import ScheduleScreen from './components/ScheduleScreen';
import LeagueScreen from './components/LeagueScreen';
import LoginScreen from './components/LoginScreen';
import RegisterScreen from './components/RegisterScreen';
import ProtectedRoute from './components/ProtectedRoute';
import { AuthProvider } from './auth/AuthContext';

const AppLayout: React.FC = () => (
  <div className="w-[390px] h-[844px] bg-gradient-to-b from-[#0a101f] to-[#121a33] rounded-[40px] overflow-hidden shadow-2xl relative flex flex-col border-4 border-gray-800">
    <Header />
    <main className="flex-1 overflow-y-auto no-scrollbar text-gray-200 p-4 pt-0">
      <Outlet />
    </main>
    <FooterNav />
  </div>
);

const PlaceholderScreen: React.FC<{ title: string }> = ({ title }) => (
    <div className="flex items-center justify-center h-full">
        <h1 className="text-2xl font-bold text-cyan-400">{title} Screen</h1>
    </div>
);

const App: React.FC = () => {
  return (
    <AuthProvider>
      <HashRouter>
        <Routes>
          <Route path="/login" element={<LoginScreen />} />
          <Route path="/register" element={<RegisterScreen />} />
          
          <Route path="/*" element={
            <ProtectedRoute>
              <Routes>
                <Route path="/" element={<AppLayout />}>
                  <Route index element={<HomeScreen />} />
                  <Route path="group" element={<ScheduleScreen />} />
                  <Route path="league" element={<LeagueScreen />} />
                  <Route path="transfer" element={<PlaceholderScreen title="Transfer" />} />
                  <Route path="store" element={<PlaceholderScreen title="Store" />} />
                   <Route path="goals" element={<PlaceholderScreen title="Goals" />} />
                   <Route path="friends" element={<PlaceholderScreen title="Friends" />} />
                  <Route path="*" element={<Navigate to="/" />} />
                </Route>
              </Routes>
            </ProtectedRoute>
          } />
        </Routes>
      </HashRouter>
    </AuthProvider>
  );
};

export default App;