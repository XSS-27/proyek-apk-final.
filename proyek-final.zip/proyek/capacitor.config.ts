import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.example.app',
  appName: 'e-sports-team-manager',
  webDir: 'dist'
};

export default config;
